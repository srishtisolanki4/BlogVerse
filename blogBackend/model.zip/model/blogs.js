const mongoose= require ('mongoose');


const blogSchema = mongoose.Schema({
    author:{
        type: mongoose.Schema.Types.ObjectId, ref: 'user'
    }
,
    title:String,
    content:String,
    date:Date,
});

module.exports = mongoose.model("blog" , blogSchema);