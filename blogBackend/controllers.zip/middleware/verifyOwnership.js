const jwt=require('jsonwebtoken');
const cookie=require('cookie-parser');
const dotenv=require('dotenv').config();
const User = require("../model/user");
const Blog= require('../model/blogs')


const verify=async (req,res,next)=>{
    try{
        const token=req.cookies.token;
        if(!token){
            return res.status(204).json({message:"Token not found!"})
        }
        const decoded= jwt.verify(token , process.env.JWT_SECRET);
        const findUser = await User.findOne({email:decoded.email});
        if(!findUser){
            return res.status(204).json({message:"No user found"});
        }
        req.user=findUser;
        const id=req.params.id;
        const blog= await Blog.findOne({_id:id});
        if(!blog.author.toString()===req.user._id){
            return res.status(204).json({message:"Unauthorized"})
        }
        next();
    }
    catch(err){
        return res.status(401).json(err.message);
    }
}

const verifyUser= async(req,res,next)=>{
    try{
        const token=req.cookies.token;
        if(!token){
            return res.status(204).json({message:"token not found"});
        }
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const findUser= await User.findOne({email:decoded.email});
        if(!findUser){
            return res.status(204).json({message:"user not found"});
        }
        next();
    }catch(err){
        return res.status(401).json(err.message);
    }

}

module.exports ={verify, verifyUser};