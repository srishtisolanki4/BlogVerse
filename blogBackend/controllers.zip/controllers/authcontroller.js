const jwt = require('jsonwebtoken');
const dotenv=require('dotenv');
const cookie=require('cookie-parser');
const bcrypt = require('bcrypt');
const User= require('../model/user')

dotenv.config();

const register=async(req,res)=>{
    try{
        const {name,email,password}= req.body;
        if(!name|| !email || !password){
            return res.status(400).json("Please enter all details");
        }
        const existingUser = await User.findOne({email});
        if(existingUser){
            return res.status(400).json({message:"Please Login"});
        }
        const salt = await bcrypt.genSalt(10);
        const hashedPassword= await bcrypt.hash(password, salt);

        const newUser = new User({
            name,
            email,
            password:hashedPassword
        });
        await newUser.save();

        const token= jwt.sign({name:newUser.name , email:newUser.email} , process.env.JWT_SECRET , {expiresIn:"1h"});
        res.cookie(
           "token" , token, {maxAge:60*60*1000}
        );
        return res.status(200).json({
            message:"Registered successfully",
            token,
            user:{
                name:newUser.name
            }
        });

    }catch(err){
        return res.status(404).json(err.message);
    }

}

const login = async(req,res)=>{
    try{
    const {email,password}=req.body;
    const oldUser= await User.findOne({email});
    if(!oldUser){
        return res.status(204).json({message:"Please Register"});
    }
    const salt= await bcrypt.genSalt(10);
    const compared = await bcrypt.compare(password,oldUser.password);
    if(!compared){
        return res.status(204).json({message:"Invalid credentials"})
    }
    const token= jwt.sign({email:oldUser.email} , process.env.JWT_SECRET , {expiresIn:"1h"});
    res.cookie(
        "token" , token , {maxAge:60*60*1000}
    );
    return res.status(200).json({
        message:"Logged in successfully",
        token,
         email:oldUser.email,
    })
}catch(err){
    return res.status(404).json({message:"internal server error"});
}
}

module.exports={register , login}