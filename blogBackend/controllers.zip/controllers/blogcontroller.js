const Blog= require('../model/blogs')

const home = async(req,res)=>{
    const blogs= await Blog.find();
    res.send(blogs);
}

const readBlog= async(req,res)=>{
    try{
            const response= await Blog.findOne({_id :req.params.id});
            res.send(response);
        }catch(err){
            console.log(err);
        }
};

const createBlog = async(req,res)=>{
    try{
            const blog=req.body;
            console.log(blog);
            const newBlog= new Blog(blog);
            await newBlog.save();
            console.log("Saved successfully!");
            res.status(201).json("yoho");
        }catch(err){
            console.log(err);
        }
}

const editBlog= async(req,res)=>{
    const id = req.params.id;
        try{
            let updatedBlog = await Blog.findOneAndUpdate({_id:id} ,
            { $set : {title: req.body.title ,content: req.body.content , date:new Date()}} , {new:true}
        );
        res.send(updatedBlog);
    
        }catch(err){
            console.log(err);
        }
}

const deleteBlog = async(req,res)=>{
    const id= req.params.id;
        try{
            let deletedBlog = await Blog.findOneAndDelete({_id:id});
            res.send(deletedBlog);
        }catch(err){
            console.log(err);
        }
}

module.exports ={home,readBlog,createBlog,editBlog,deleteBlog};