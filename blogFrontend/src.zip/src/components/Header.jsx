function Header(){
    return(
        <>
            <div className="text-center text-zinc-800 mt-5 mb-5">
                <h1 className="text-4xl  font-bold mb-1">My Blog</h1>
                <h4 className="text-xl">Life | Thoughts | Code</h4>

            </div>
        </>
    )

}

export default Header