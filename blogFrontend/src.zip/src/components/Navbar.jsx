import {Link}  from 'react-router-dom'
import BlogIcon from '../assets/blog.png'
function Navbar(){
    return(
        <div className='p-2 bg-zinc-500 '>

            <div ><img  className='h-12'src={BlogIcon}></img></div>
            <div className='flex flex-row justify-end'>
                 <div className='text-xl  m-2 -mt-12 p-2 px-3 hover:underline'> <Link to='/'>Home</Link> </div>  
                <div className=' text-xl m-2  -mt-12  p-2 px-3 hover:underline'> <Link to='/about'>About</Link> </div>
                <div className=' text-xl m-2 -mt-12  p-2 px-3 hover:underline'> <Link to='/blog'>Blog</Link> </div>
                <div className=' text-xl m-2 -mt-12  p-2 px-3 hover:underline'> <Link to='/login'>Login</Link> </div>


            </div>
            
             
             

        </div>
        

    );

}

export default Navbar