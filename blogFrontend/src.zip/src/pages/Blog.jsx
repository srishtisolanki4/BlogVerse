import Navbar from "../components/Navbar";
import Header from "../components/Header";
import React,{useState} from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';

function Blog(){
    const navigate=useNavigate();

    const[blogTitle , setBlogTitle]=useState("");
    const[blogAuthor, setBlogAuthor]=useState("");
    const[blogContent , setBlogContent]=useState("");
    const[blogDate , setBlogDate] = useState(new Date());
    
    async function handleAddBlog(event){
        setBlogDate(new Date());
        event.preventDefault();
        const newBlog={
            author: blogAuthor, 
            title: blogTitle,
            content: blogContent, 
            date: blogDate,
            
        };
        
        
        try{
            const response = await axios.post(("http://127.0.0.1:3000/create"), {newBlog} , {withCredentials:true});
            console.log("Blog saved",response);
            console.log("About to call navigate")
            navigate("/");
        }catch(err){
            console.log(err.message);
        }


        setBlogTitle("");
        setBlogAuthor("");
        setBlogContent("");

    }

    function handleTitle(event){
        setBlogTitle(event.target.value);
    }


    function handleContent(event){
        setBlogContent(event.target.value);
    }    

    function handleAuthor(event){
        setBlogAuthor(event.target.value);
    }

    return(
        <>
        <Navbar/>
        <Header/>
            <div className="max-w-xl mx-auto bg-blue-50 p-6 rounded-xl shadow-md space-y-4 mt-4 ">
                 <h2 className="text-2xl font-bold text-center">✍️ Write a New Blog</h2>
                <input className="w-full p-2 border border-zinc-400 shadow-md rounded-md" name="author" value={blogAuthor} onChange={handleAuthor} placeholder="Enter your name"></input>
                <input className="w-full p-2 border border-zinc-400 shadow-md rounded-md " type="text" name="title" value={blogTitle} onChange={handleTitle} placeholder="Title of your blog"></input>
                <textarea className="w-full p-2 border border-zinc-400 shadow-md rounded-md min-h-[150px] " type="text"  name="content" value={blogContent} onChange={handleContent} placeholder="Write your blog here..."></textarea>
                <button  className=" w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 shadow-lg" type="submit" onClick={handleAddBlog} >Create Blog</button>
            </div>
            
           
        
        </>
        
    )

}
export default Blog;