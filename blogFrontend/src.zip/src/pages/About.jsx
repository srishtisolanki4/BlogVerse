import AboutContent from "../components/AboutContent";
import Navbar from "../components/Navbar";

function About(){
    return(
        <>
         <Navbar/>
         
         <AboutContent/>
        </>
    )

}
export default About;